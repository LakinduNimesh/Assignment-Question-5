package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LibraryIntegrationTest {
    private Library library;

    @BeforeEach
    void setUp() {
        library = new Library();
    }

    @Test
    void testAddAndSearchBook() {
        library.addBook("Kadol Aththu", "Kamal Gunarathna", 1);
        assertNotNull(library.searchBook("Kadol Aththu"));
    }

    @Test
    void testAddAndDeleteBook() {
        library.addBook("Kadol Aththu", "Kamal Gunarathna", 1);
        library.deleteBook(1);
        assertNull(library.searchBook("Kadol Aththu"));
    }
}