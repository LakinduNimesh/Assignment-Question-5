package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class LibrarySystemTest {

    private Library library;

    @BeforeEach
    public void setUp() {
        library = new Library();
    }

    @Test
    public void testAddBook() {
        System.out.println("Test Case 1: Add a book");
        library.addBook("Deathly Hallows", "JK Rowling", 1);
        library.addBook("Lost World", "Arthur Conan Doyle", 2);

        System.out.println("Expected: 2 books added.");
        library.displayBooks();
        System.out.println();
    }

    @Test
    public void testDisplayBooks() {
        System.out.println("Test Case 2: Display all books");
        library.addBook("Deathly Hallows", "JK Rowling", 1);
        library.addBook("Lost World", "Arthur Conan Doyle", 2);
        library.displayBooks();
        System.out.println();
    }

    @Test
    public void testSearchBook() {
        System.out.println("Test Case 3: Search for a book");
        library.addBook("Deathly Hallows", "JK Rowling", 1);
        assertNotNull(library.searchBook("Deathly Hallows"));
        assertNull(library.searchBook("Kadol Aththu"));
        System.out.println();
    }

    @Test
    public void testDeleteBook() {
        System.out.println("Test Case 4: Delete a book");
        library.addBook("Deathly Hallows", "JK Rowling", 1);
        library.deleteBook(1);
        assertNull(library.searchBook("Deathly Hallows"));
        System.out.println("Expected: Book with ID 1 deleted.");
        System.out.println("Actual: " + (library.searchBook("Deathly Hallows") == null ? "Book deleted." : "Book not deleted."));
        library.displayBooks();
        System.out.println();
    }

    @Test
    public void testDeleteNonExistentBook() {
        System.out.println("Test Case 5: Attempt to delete a non-existent book");
        library.deleteBook(3);
        System.out.println("Expected: No error, operation completed.");
        System.out.println("Actual: Attempted to delete non-existent book.");
        System.out.println();
    }

    @Test
    public void testSearchDeletedBook() {
        System.out.println("Test Case 6: Search for a deleted book");
        library.addBook("Deathly Hallows", "JK Rowling", 1);
        library.deleteBook(1);
        assertNull(library.searchBook("Deathly Hallows"));
        System.out.println("Expected: Book not found.");
        System.out.println("Actual: " + (library.searchBook("Deathly Hallows") == null ? "Book not found." : "Book found."));
        System.out.println();
    }

    @Test
    public void testDisplayBooksAfterDeletion() {
        System.out.println ("Test Case 7: Display all books after deletion");
        library.addBook("Deathly Hallows", "JK Rowling", 1);
        library.deleteBook(1);
        library.displayBooks();
    }
}