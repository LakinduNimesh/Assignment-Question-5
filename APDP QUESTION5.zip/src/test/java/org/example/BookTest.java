package org.example;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;



class BookTest {
    private Book book;

    @BeforeEach
    void setUp() {
        book = new Book("Kadol Aththu", "Kamal Gunarathne", 1);
    }

    @Test
    void testGetTitle() {
        assertEquals("Kadol Aththu", book.getTitle());
    }

    @Test
    void testGetAuthor() {
        assertEquals("Kamal Gunarathne", book.getAuthor());
    }

    @Test
    void testGetId() {
        assertEquals(1, book.getId());
    }
}