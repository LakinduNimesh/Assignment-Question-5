package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class BankAccountTest {
    private BankAccount account1;
    private BankAccount account2;

    @BeforeEach
    public void setUp() {
        account1 = new BankAccount("Lakindu", 100.0);
        account2 = new BankAccount("Nimesh", 50.0);
    }

    @Test
    public void testDeposit() {
        account1.deposit(200.0);
        assertEquals(200.0, account1.getBalance());

        account1.deposit(-50.0);
        assertEquals(200.0, account1.getBalance());
    }

    @Test
    public void testWithdraw() {
        account1.deposit(200.0);
        account1.withdraw(50.0);
        assertEquals(150.0, account1.getBalance());

        account1.withdraw(200.0);
        assertEquals(-50.0, account1.getBalance());

        account1.withdraw(200.0);
        assertEquals(-50.0, account1.getBalance());
    }

    @Test
    public void testTransfer() {
        account1.deposit(300.0);
        account1.transfer(account2, 100.0);
        assertEquals(200.0, account1.getBalance());
        assertEquals(100.0, account2.getBalance());

        account1.transfer(account2, 500.0);
        assertEquals(200.0, account1.getBalance());
        assertEquals(100.0, account2.getBalance());
    }

    @Test
    public void testAddInterest() {
        account1.deposit(1000.0);
        account1.addInterest(5.0);
        assertEquals(1050.0, account1.getBalance());

        account1.addInterest(-10.0);
        assertEquals(1050.0, account1.getBalance());
    }

    @Test
    public void testTransactionHistory() {
        account1.deposit(100.0);
        account1.withdraw(50.0);
        account1.addInterest(10.0);


        assertEquals(3, account1.transactionHistory.size());
    }
}
