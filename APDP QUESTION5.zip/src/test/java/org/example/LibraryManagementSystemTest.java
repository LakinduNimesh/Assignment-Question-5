package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LibraryManagementSystemTest {

    @Test
    public void testAddBook() {
        Library library = new Library();
        library.addBook("Book1", "Author1", 1);
        library.addBook("Book2", "Author2", 2);
        assertEquals(2, library.getBooksCount());
    }

    @Test
    public void testAddDuplicateBook() {
        Library library = new Library();
        library.addBook("Book1", "Author1", 1);
        library.addBook("Book1", "Author1", 1);
        assertEquals(1, library.getBooksCount());
    }

    @Test
    public void testDeleteBook() {
        Library library = new Library();
        library.addBook("Book1", "Author1", 1);
        library.deleteBook(1);
        assertEquals(0, library.getBooksCount());
    }

    @Test
    public void testDeleteNonExistentBook() {
        Library library = new Library();
        library.deleteBook(1);
        assertEquals(0, library.getBooksCount());
    }
}