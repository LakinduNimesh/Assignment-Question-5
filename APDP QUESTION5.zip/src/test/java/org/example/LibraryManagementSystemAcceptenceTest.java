
package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class LibraryManagementSystemAcceptenceTest {
    private Library library;

    @BeforeEach
    public void setUp() {
        library = new Library();
    }

    @Test
    public void testLibraryFunctionality() {

        library.addBook("Lost World", "Arthur connon Doil", 1);
        library.addBook("harry potter and deathly hallows", "JK Rowlling", 2);


        assertEquals(2, library.getBooksCount());


        library.addBook("Kadol Aththu", "kamal Gnarathna", 1);
        assertEquals(2, library.getBooksCount());


        library.deleteBook(1);
        assertEquals(1, library.getBooksCount());


        library.deleteBook(3);
        assertEquals(1, library.getBooksCount());


        Book foundBook = library.searchBook("harry potter and deathly hallows");
        assertNotNull(foundBook);
        assertEquals("JK Rowlling", foundBook.getAuthor()); // Verify author


        Book notFoundBook = library.searchBook("Unknown Book");
        assertNull(notFoundBook);


        library.displayBooks();
    }
}