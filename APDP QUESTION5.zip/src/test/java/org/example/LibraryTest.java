package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LibraryTest {
    private Library library;

    @BeforeEach
    void setUp() {
        library = new Library();
    }

    @Test
    void testAddBook() {
        library.addBook("Kadol Aththu", "Kamal Gunarathna", 1);
        assertNotNull(library.searchBook("Kadol Aththu"));
    }

    @Test
    void testDeleteBook() {
        library.addBook("Kadol Aththu", "Kamal Gunarathna", 1);
        library.deleteBook(1);
        assertNull(library.searchBook("Kadol Aththu"));
    }

    @Test
    void testSearchBook() {
        library.addBook("Kadol Aththu", "Kamal Gunarathna", 1);
        assertNotNull(library.searchBook("Kadol Aththu"));
        assertNull(library.searchBook("Non-existent Book"));
    }

    @Test
    void testDisplayBooks() {
        library.addBook("Kadol Aththu", "Kamal Gunarathna", 1);
        library.displayBooks();
    }
}