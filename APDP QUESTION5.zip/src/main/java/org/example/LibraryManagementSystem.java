package org.example;

import java.util.ArrayList;
import java.util.Scanner;

class Book {
    private String title;
    private String author;
    private int id;

    public Book(String title, String author, int id) {
        this.title = title;
        this.author = author;
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getId() {
        return id;
    }
}

class Library {
    private ArrayList<Book> books = new ArrayList<>();

    public void addBook(String title, String author, int id) {

        for (Book book : books) {
            if (book.getId() == id) {
                System.out.println(" Book with ID " + id + " already exists. Cannot add.");
                return;
            }
        }
        Book newBook = new Book(title, author, id);
        books.add(newBook);
        System.out.println(" Book added : " + title);
    }

    public void deleteBook(int id) {
        boolean removed = books.removeIf(book -> book.getId() == id);
        if (removed) {
            System.out.println(" Book with ID " + id + " removed.");
        } else {
            System.out.println(" Book with ID " + id + " not found. Cannot delete.");
        }
    }

    public Book searchBook(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                System.out.println(" Book found : " + title + " by " + book.getAuthor());
                return book;
            }
        }
        System.out.println(" Book not found: " + title);
        return null;
    }

    public void displayBooks() {
        System.out.println(" All Books in Library:");
        for (Book book : books) {
            System.out.println(" ID     : " + book.getId());
            System.out.println(" Title  : " + book.getTitle());
            System.out.println(" Author : " + book.getAuthor());
        }
    }


    public int getBooksCount() {
        return books.size();
    }
}

public class LibraryManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Library library = new Library();

        while (true) {
            System.out.println();
            System.out.println("+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+");
            System.out.println("+                                                   +");
            System.out.println("+             Library Management System             +");
            System.out.println("+                                                   +");
            System.out.println("+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+");
            System.out.println();
            System.out.println("1. Add Book");
            System.out.println("2. Delete Book");
            System.out.println("3. Search Book");
            System.out.println("4. Display All Books");
            System.out.println("5. Exit");
            System.out.print(" Choose an option (1/2/3/4) : ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print(" Enter title : ");
                    String title = scanner.nextLine();
                    System.out.print(" Enter author: ");
                    String author = scanner.nextLine();
                    System.out.print(" Enter ID    : ");
                    int id = scanner.nextInt();
                    library.addBook(title, author, id);
                    break;
                case 2:
                    System.out.print(" Enter ID of book to delete   : ");
                    int deleteId = scanner.nextInt();
                    library.deleteBook(deleteId);
                    break;
                case 3:
                    System.out.print(" Enter title of book to search: ");
                    String searchTitle = scanner.nextLine();
                    library.searchBook(searchTitle);
                    break;
                case 4:
                    library.displayBooks();
                    break;
                case 5:
                    System.out.println(" Exiting the system.");
                    System.exit(0);
                    break;
                default:
                    System.out.println(" Invalid choice. Please try again.");
            }
        }
    }
}