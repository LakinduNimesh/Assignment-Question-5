package org.example;


import java.util.ArrayList;

public class BankAccount {
    private static int nextAccountNumber = 1000;
    private final int accountNumber;
    private String accountHolderName;
    private double balance;
    private final double overdraftLimit;
    ArrayList<String> transactionHistory;


    public BankAccount(String accountHolderName, double overdraftLimit) {
        this.accountNumber = nextAccountNumber++;
        this.accountHolderName = accountHolderName;
        this.balance = 0.0;
        this.overdraftLimit = overdraftLimit;
        this.transactionHistory = new ArrayList<>();
    }


    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            transactionHistory.add("Deposited: Rs" + amount);
            System.out.println("Deposited: Rs" + amount);
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }


    public void withdraw(double amount) {
        if (amount > 0 && (balance + overdraftLimit) >= amount) {
            balance -= amount;
            transactionHistory.add("Withdrew: Rs" + amount);
            System.out.println("Withdrew: Rs" + amount);
        } else if (amount > (balance + overdraftLimit)) {
            System.out.println("Insufficient balance and overdraft limit.");
        } else {
            System.out.println("Withdrawal amount must be positive.");
        }
    }


    public void transfer(BankAccount recipient, double amount) {
        if (amount > 0 && (balance + overdraftLimit) >= amount) {
            this.withdraw(amount);
            recipient.deposit(amount);
            transactionHistory.add("Transferred: Rs" + amount + " to Account " + recipient.getAccountNumber());
            System.out.println("Transferred: Rs" + amount + " to Account " + recipient.getAccountNumber());
        } else {
            System.out.println("Transfer failed. Check balance or overdraft limit.");
        }
    }


    public void addInterest(double interestRate) {
        if (interestRate > 0) {
            double interest = (balance > 0) ? (balance * interestRate / 100) : 0;
            balance += interest;
            transactionHistory.add("Interest added: Rs" + interest);
            System.out.println("Interest added: Rs" + interest);
        } else {
            System.out.println("Interest rate must be positive.");
        }
    }


    public int getAccountNumber() {
        return accountNumber;
    }


    public double getBalance() {
        return balance;
    }


    public void showTransactionHistory() {
        System.out.println("Transaction History for Account " + accountNumber + ":");
        for (String transaction : transactionHistory) {
            System.out.println(transaction);
        }
    }


    public void setAccountHolderName(String name) {
        if (!name.isEmpty()) {
            this.accountHolderName = name;
        }
    }


    public String getAccountHolderName() {
        return accountHolderName;
    }


    public static void main(String[] args) {

        BankAccount account1 = new BankAccount("Lakindu", 100.0);
        BankAccount account2 = new BankAccount("Nimesh", 50.0);


        System.out.println("Account Number: " + account1.getAccountNumber() + ", Account Holder: " + account1.getAccountHolderName());
        System.out.println("Account Number: " + account2.getAccountNumber() + ", Account Holder: " + account2.getAccountHolderName());


        account1.deposit(200.0);
        account1.deposit(50.0);


        account1.withdraw(30.0);
        account1.withdraw(250.0);


        account1.transfer(account2, 100.0);
        account1.transfer(account2, 200.0);


        account1.addInterest(5);


        account1.showTransactionHistory();
        account2.showTransactionHistory();


        System.out.println("Current Balance of Account " + account1.getAccountNumber() + ": Rs" + account1.getBalance());
        System.out.println("Current Balance of Account " + account2.getAccountNumber() + ": Rs" + account2.getBalance());
    }
}
